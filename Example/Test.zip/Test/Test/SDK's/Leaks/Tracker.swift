//
//  FirebaseConnector.swift
//  Test
//
//  Created by khayal suleymani on 27.01.26.
//


import Common
#if canImport(LifetimeTracker)
import LifetimeTracker
#endif

typealias SDK_4 = LifetimeTrackerConnector

// MARK: Memory leak monitor connector...
class LifetimeTrackerConnector: Connector {
    
#if canImport(LifetimeTracker)
    override func application(_ application: UIApplication,
                              didFinishLaunchingWithOptions
                              launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
#if DEBUG
        LifetimeTracker.setup(
            onLeakDetected: { entity, _ in
                debugPrint("POSSIBLE LEAK ALERT: \(entity.name) - current count: \(entity.count), max count: \(entity.maxCount)")
            }, onUpdate: LifetimeTrackerDashboardIntegration(
                visibility: .alwaysVisible,
                style: .bar)
            .refreshUI)
#endif
        return true
    }
#endif
    
}
