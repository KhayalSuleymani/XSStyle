//
//  FirebaseCrashlyticsConnector.swift
//  Test
//
//  Created by khayal suleymani on 16.09.25.
//

import Common
#if canImport(FirebaseCrashlytics)
import FirebaseCrashlytics
#endif

class FirebaseCrashlyticsConnector: Connector {
    
#if canImport(FirebaseCrashlytics)
    override func application(_ application: UIApplication,
                              didFinishLaunchingWithOptions
                              launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
#if canImport(Swinject)
        DI.register(FirebaseCrashlyticsInjectable.self) { _ in self }
#endif
        
        return true
    }
    
#endif
    
}

#if canImport(FirebaseCrashlytics)
extension FirebaseCrashlyticsConnector: FirebaseCrashlyticsInjectable {
    func inject(_ view: UIViewController) {
        // inject view to the FirebaseCrashlytics from here...
    }
}
#endif
