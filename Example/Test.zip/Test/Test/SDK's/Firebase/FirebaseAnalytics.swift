//
//  FirebaseConnector.swift
//  Test
//
//  Created by khayal suleymani on 16.09.25.
//

import Common
#if canImport(FirebaseAnalytics)
import FirebaseAnalytics
#endif

class FirebaseAnalyticsConnector: Connector {
    
#if canImport(FirebaseAnalytics)
    override func application(_ application: UIApplication,
                              didFinishLaunchingWithOptions
                              launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
#if canImport(Swinject)
        DI.register(FirebaseAnalyticsInjectable.self) { _ in self }
#endif
        return true
    }
    
#endif
    
}

#if canImport(FirebaseAnalytics)
extension FirebaseAnalyticsConnector: FirebaseAnalyticsInjectable {
    func inject(_ view: UIViewController) {
        // inject view to the FirebaseAnalytics from here...
    }
}
#endif
