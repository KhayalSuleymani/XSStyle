//
//  FirebaseConnector.swift
//  Test
//
//  Created by khayal suleymani on 16.09.25.
//

import Common
#if canImport(Firebase)
import Firebase
#endif

typealias SDK_1 = FirebaseConnector

class FirebaseConnector: Connector {
    // firebase composite
    convenience override init () {
        self.init(connections: [
            FirebaseAnalyticsConnector(),
            FirebaseCrashlyticsConnector(),
        ])
    }
}
