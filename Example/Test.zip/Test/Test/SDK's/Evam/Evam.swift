//
//  EvamConnector.swift
//  Test
//
//  Created by khayal suleymani on 16.09.25.
//

import Common
#if canImport(Evam_iOS_Common_Kit)
import Evam_iOS_Common_Kit
#endif
#if canImport(Swinject)
import Swinject
#endif

typealias SDK_2 = EvamConnector

class EvamConnector: Connector {
    // evam composite
    convenience override init () {
        self.init(connections: [
            EvamAnalyticsConnector(),
            EvamMessagesConnector()
        ])
    }
}
