//
//  Evam(in-App).swift
//  Test
//
//  Created by khayal suleymani on 29.12.25.
//

import Common
#if canImport(Evam_iOS_Common_Kit)
import Evam_iOS_Common_Kit
#endif

class EvamMessagesConnector: Connector {
#if canImport(Evam_iOS_Common_Kit)
    override func application(_ application: UIApplication,
                              didFinishLaunchingWithOptions
                              launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {

#if canImport(Swinject)
        DI.register(EvamMessagesInjectable.self) { _ in self }
#endif
        
        return true
    }
#endif
}

#if canImport(Evam_iOS_Common_Kit)
extension EvamMessagesConnector: EvamMessagesInjectable {
    func inject(_ view: UIViewController) {
        // inject view to the EvamMessages from here...
    }
}
#endif
