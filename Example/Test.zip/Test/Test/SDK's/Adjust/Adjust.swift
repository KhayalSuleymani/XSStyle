//
//  AdjustConnector.swift
//  Test
//
//  Created by khayal suleymani on 16.09.25.
//

import Common
#if canImport(Adjust)
import Adjust
#endif

typealias SDK_3 = AdjustConnector

class AdjustConnector: Connector {
    // adjust composite
    convenience override init () {
        self.init(connections: [
            AdjustAnalyticsConnector(),
            AdjustCrashlyticsConnector(),
        ])
    }
}
