//
//  FirebaseConnector.swift
//  Test
//
//  Created by khayal suleymani on 16.09.25.
//

import Common
#if canImport(AdjustAnalytics)
import AdjustAnalytics
#endif

class AdjustAnalyticsConnector: Connector {
    
#if canImport(AdjustAnalytics)
    override func application(_ application: UIApplication,
                              didFinishLaunchingWithOptions
                              launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
#if canImport(Swinject)
        DI.register(AdjustAnalyticsInjectable.self) { _ in self }
#endif
        
        return true
    }
    
#endif
    
}

#if canImport(AdjustAnalytics)
extension AdjustAnalyticsConnector: AdjustAnalyticsInjectable {
    func inject(_ view: UIViewController) {
        // inject view to the AdjustAnalytics from here...
    }
}
#endif
