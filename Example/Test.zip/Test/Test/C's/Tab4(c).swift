//
//  Tab1(c).swift
//  Test
//
//  Created by khayal suleymani on 05.02.26.
//

import Common
import Cards
import Deposits
import Ibans
import Loans

// MARK: Tab4 Coordinator

public class Tab4: Coordinator<ProductsRoute> {                         // ---------------
    @discardableResult                                                  //                |
    override public func move(by route: ProductsRoute) -> Self {        //                |
        switch route {                                                  //                |
        case .cards:                                                    //                |
            let c = Cards()                                             // C ---------    |
            show(v: c)                                                  //            |   |
        case .accounts(_):                                              //            |   |
            let c = Accounts()                                          // C ---------|
            show(v: c)                                                  //            |-- C
        case .deposits(_):                                              //            |
            let c = Deposits()                                          // C ---------|   |
            show(v: c)                                                  //            |   |
        case .loans(_):                                                 //            |   |
            let c = Loans()                                             // C ---------    |
            show(v: c)                                                  //                |
        }                                                               //                |
        return self                                                     //                |
    }                                                                   //                |
}                                                                       // ---------------
