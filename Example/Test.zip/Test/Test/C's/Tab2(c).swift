//
//  Tab1(c).swift
//  Test
//
//  Created by khayal suleymani on 05.02.26.
//

import Common
import Payments
import Transfers

// MARK: Tab2 Coordinator
public class Tab2: Coordinator<OperationsRoute> {                       // ---------------
    @discardableResult                                                  //                |
    override public func move(by route: OperationsRoute) -> Self {      //                |
        switch route {                                                  //                |
        case .payments(let r):                                          //                |
            let c = Payments(r)                                         // C ---------    |
            show(v: c)                                                  //            |
        case .transfers(let r):                                         //            |-- C
            let c = Transfers(r)                                        //            |
            push(v: c)                                                  // C ---------    |
        }                                                               //                |
        return self                                                     //                |
    }                                                                   //                |
}                                                                       // ---------------
