//
//  AppDelegate.swift
//  Test
//
//  Created by khayal suleymani on 16.09.25.
//

import Common

// MARK: App Delegate

@main class Main: App {
    
    /// app coordinator connection
    override var controller: Test {
        Test()                          // -------- C
    }
    
    /// app third parties connection
    override var connector: Connector { // ----------
        .init(connections: [            //           |
            SDK_1(),                    // firebase
            SDK_2(),                    // evam      A (adapter)
            SDK_3(),                    // adjust
            SDK_4(),                    // tracker   |
        ])                              // ----------
    }
}
