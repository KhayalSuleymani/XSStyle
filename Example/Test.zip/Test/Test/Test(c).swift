//
//  Test 2.swift
//  Test
//
//  Created by khayal suleymani on 24.09.25.
//

import Common
import Authorize

// MARK: Test Coordinator

public class Test: Coordinator<AppRoute> {                              // ---------------
    @discardableResult                                                  //                |
    override public func move(by route: AppRoute) -> Self {             //                |
        switch route {                                                  //                |
        case .authorize(let r):                                         //                |
            let c = Authorize(r)                                        // C --------     |
            show(v: c)                                                  //            |   |
        case .dashboard(_):                                             //            |
            let c = Tab(tabs: [                                         //            |-- C
                Tab1(),                                                 //            |
                Tab2(),                                                 //            |   |
                Tab3(),                                                 // C --------     |
                Tab4(),                                                 //                |
            ])                                                          //                |
            overFull(v: c)                                              //                |
        }                                                               //                |
        return self                                                     //                |
    }                                                                   //                |
}                                                                       // ---------------
