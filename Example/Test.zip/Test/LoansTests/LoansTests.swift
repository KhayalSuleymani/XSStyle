//
//  LoansTests.swift
//  LoansTests
//
//  Created by khayal suleymani on 03.02.26.
//

import XCTest
@testable import Loans

@MainActor
final class LoansTests: XCTestCase {
    func test () {
        let sut = Loans()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
    }
}
