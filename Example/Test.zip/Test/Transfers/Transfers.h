//
//  Transfers.h
//  Transfers
//
//  Created by khayal suleymani on 22.01.26.
//

#import <Foundation/Foundation.h>

//! Project version number for Transfers.
FOUNDATION_EXPORT double TransfersVersionNumber;

//! Project version string for Transfers.
FOUNDATION_EXPORT const unsigned char TransfersVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Transfers/PublicHeader.h>


