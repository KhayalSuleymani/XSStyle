//
//  ViwwStyle1.swift
//  Test
//
//  Created by khayal suleymani on 24.09.25.
//

import Common

// Model

class Model2: ViewStyle<Transfer> {
        
    override var sectionsStyle: [SectionStyle] {
        
        // fill section manual indirect...
        let s1 = SectionStyle()
        
        // component1
        let s1_c1 = ImageLabelButtonComponentStyle(
            s1: .style(.s1(data?.amount)),
            s2: .style(.s2("Hello")),
            s3: .style(.s3(.s1("https://"), event: event(_:))))
        
        // component2
        let s1_c2 = ImageLabelLabelComponentStyle2(
            s1: .style(.s1("https://via.placeholder.com/150")),
            s2: .style(.s1("Hello...")),
            s3: .style(.s2("Hello...")))
        
        s1.add(s1_c1)
        s1.add(s1_c2)
        
        return [ s1 ]
    }
}

