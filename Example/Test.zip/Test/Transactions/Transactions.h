//
//  Transactions.h
//  Transactions
//
//  Created by khayal suleymani on 14.10.25.
//

#import <Foundation/Foundation.h>

//! Project version number for Transactions.
FOUNDATION_EXPORT double TransactionsVersionNumber;

//! Project version string for Transactions.
FOUNDATION_EXPORT const unsigned char TransactionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Transactions/PublicHeader.h>


