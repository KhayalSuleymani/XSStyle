//
//  PaymentsTests.swift
//  PaymentsTests
//
//  Created by khayal suleymani on 22.01.26.
//

import XCTest
@testable import Payments

@MainActor
final class PaymentsTests: XCTestCase {
    func test () {
        let sut = Payments()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
    }
}
