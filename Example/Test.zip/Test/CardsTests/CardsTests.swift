//
//  CardsTests.swift
//  CardsTests
//
//  Created by khayal suleymani on 03.02.26.
//

import XCTest
@testable import Cards

@MainActor
final class CardsTests: XCTestCase {
    func test () {
        let sut = Cards()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
    }
}
