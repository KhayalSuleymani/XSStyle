//
//  Inheritance.swift
//  Transactions
//
//  Created by khayal suleymani on 22.12.25.
//

import Common

// #MARK: DOMAIN LAYER
public typealias Route = CardsRoute

/// Domain Model
class ViewStyle<D>: GenericViewStyle<D> { }

/// Domain ViewModel
class ViewModel<M: Common.ViewStyle>: Common.ViewModel<M,Route> { }

