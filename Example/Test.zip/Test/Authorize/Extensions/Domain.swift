//
//  Inheritance.swift
//  Transactions
//
//  Created by khayal suleymani on 22.12.25.
//

import Common

// MARK: DOMAIN LAYER

public typealias Route = AuthorizeRoute

// MARK: Entities
typealias Login = Route.Login
typealias Confirm = Route.Confirm
typealias Passcode = Route.Passcode
typealias User = Route.User

// MARK: Domain Model
class ViewStyle<D>: GenericViewStyle<D> { }

