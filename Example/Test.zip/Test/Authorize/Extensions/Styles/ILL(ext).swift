//
//  ImageLabelLabelComponentStyle.swift
//  Test
//
//  Created by khayal suleymani on 10.12.25.
//

import Common

extension ImageLabelLabelComponentStyle {
    
}
