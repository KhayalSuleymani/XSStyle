//
//  Authorize(c).swift
//  Authorize
//
//  Created by khayal suleymani on 24.09.25.
//

import Common

// MARK: Authorize (Model View Controller) - MVC

public class Authorize: Controller<Route> {                             // ---------------
    @discardableResult                                                  //                |
    override public func move(by route: Route) -> Self {                //                |
        switch route {                                                  //                |
        case .view1(let d):                                             //                |
            let m = Model1(d)                                           // m              |
            let v = View1()                                             // v ---------    |
            NetworkService.shared                                       //            |   |
                .request1 { d in                                        //            |   |
                    m.configure(d)                                      //            |   |
                    v.configure(m)                                      //            |   |
                }                                                       //            |   |
            push(v: v)                                                  //            |   |
        case .view2(let d):                                             //            |   |
            let m = Model2(d)                                           // m          |   |
            let v = View2()                                             // v ---------|   |
            NetworkService.shared                                       //            |   |
                .request2 { d in                                        //            |   |
                    m.configure(d)                                      //            |
                    v.configure(m)                                      //            |-- C
                }                                                       //            |
            present(v: v)                                               //            |   |
        case .view3(let d):                                             //            |   |
            let m = Model3(d)                                           // m ---------|   |
            let v = View3()                                             // v          |   |
            NetworkService.shared                                       //            |   |
                .request3 { d in                                        //            |   |
                    m.configure(d)                                      //            |   |
                    v.configure(m)                                      //            |   |
                }                                                       //            |   |
            push(v: v)                                                  //            |   |
        case .view4(let d):                                             //            |   |
            let m = Model4(d)                                           // m ---------    |
            let v = View4()                                             // v              |
            NetworkService.shared                                       //                |
                .request4 { _ in                                        //                |
                    m.configure(d)                                      //                |
                    v.configure(m)                                      //                |
                }                                                       //                |
            push(v: v)                                                  //                |
        }                                                               //                |
        return self                                                     //                |
    }                                                                   //                |
}                                                                       // ---------------
