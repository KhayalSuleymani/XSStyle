//
//  Authorize(ns).swift
//  Authorize
//
//  Created by khayal suleymani on 14.10.25.
//

import Common

class NetworkService: Common.NetworkService {
    
    static let shared = NetworkService()
    
    @discardableResult
    func request1 (_ completion: @escaping Completion<Login>) -> Self {
        requestXML(completion)
        return self
    }
    
    @discardableResult
    func request2 (_ completion: @escaping Completion<Confirm>) -> Self {
        requestJSON(completion)
        return self
    }
    
    @discardableResult
    func request3 (_ completion: @escaping Completion<Passcode>) -> Self {
        requestSOAP(completion)
        return self
    }
    
    @discardableResult
    func request4 (_ completion: @escaping Completion<User>) -> Self {
        requestJSON(completion)
        return self
    }
}
