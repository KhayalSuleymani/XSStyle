//
//  View1.swift
//  Test
//
//  Created by khayal suleymani on 24.09.25.
//

import Common

// View
typealias View1 = View<Model1>

// Model
class Model1: ViewStyle<Login> {
    
    override var sectionsStyle: [SectionStyle] {
        
        // fill section with iteration...
        let s1 = SectionStyle(items: [])
        
        // fill section with iteration...
        let s2 = SectionStyle(items: [])
        
        // fill section manual indirect...
        let s3 = SectionStyle()
        
        // component1
        let s3_c1 = ImageLabelButtonComponentStyle(
            s1: .style(.s2(.remove)),
            s2: .style(.s2("Hello")),
            s3: .style(.s3(.s1("https://"), event: event(_:)))
                .isShimmering { _ in
                    true
                }.didSelect { _ in
                    
                }).isHidden { _ in
                    true
                }
        
        // component2
        let s3_c2 = ImageLabelLabelComponentStyle2(
            s1: .style(.s1("https://via.placeholder.com/150")),
            s2: .style(.s1(data?.password)),
            s3: .style(.s2(data?.phone)))
        
        s3.add(s3_c1)
        s3.add(s3_c2)
        
        // fill section manual direct...
        let s4 = SectionStyle(items: [
            
            ImageLabelButtonComponentStyle(
                s1: .style(.s2(.remove)),
                s2: .style(.s2(.styleCSS("Hello"))),
                s3: .style(.s3(.s2(.checkmark), event: event(_:)))),
            
            ImageLabelLabelComponentStyle2(
                s1: .style(.s1("https://via.placeholder.com/150")),
                s2: .style(.s1(.styleHTML("Hello"))),
                s3: .style(.s2(.styleXML("Hello")))),
            
            ImageLabelLabelComponentStyle(
                s1: .style(.s1(.styleAttributed("Hello"))),
                s2: .style(.s1(.styleCSS(""))),
                s3: .style(.s2(.styleHTML(""))))
        ])
        
        return [ s1, s2, s3, s4 ]
    }
}
