//
//  ViwwStyle1.swift
//  Test
//
//  Created by khayal suleymani on 24.09.25.
//

import Common

// View
typealias View2 = View<Model2>

class Model2: ViewStyle<Confirm> {
    
}
