//
//  ViwwStyle1.swift
//  Test
//
//  Created by khayal suleymani on 24.09.25.
//

import Common

typealias View3 = View<Model3>

class Model3: ViewStyle<Passcode> { }
