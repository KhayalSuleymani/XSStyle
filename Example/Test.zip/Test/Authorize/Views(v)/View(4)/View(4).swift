//
//  ViwwStyle1.swift
//  Test
//
//  Created by khayal suleymani on 24.09.25.
//

import Common

typealias View4 = View<Model4>

class Model4: ViewStyle<User> {
    
    override var sectionsStyle: [SectionStyle] {
        
        let s = SectionStyle()
        
        s.add(ImageLabelComponentStyle(
            s1: .style(.s1(.styleAttributed(data?.amount))),
            s2: .style(.s2(data?.date))))
        
        return [ s ]
    }
}
