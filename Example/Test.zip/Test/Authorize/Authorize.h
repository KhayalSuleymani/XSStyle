//
//  Authorize.h
//  Authorize
//
//  Created by khayal suleymani on 24.09.25.
//

#import <Foundation/Foundation.h>

//! Project version number for Authorize.
FOUNDATION_EXPORT double AuthorizeVersionNumber;

//! Project version string for Authorize.
FOUNDATION_EXPORT const unsigned char AuthorizeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Authorize/PublicHeader.h>


