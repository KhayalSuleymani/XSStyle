//
//  Authorize(ns).swift
//  Authorize
//
//  Created by khayal suleymani on 14.10.25.
//

import Common

typealias Account = AccountsRoute.Account
typealias Receipt = AccountsRoute.Receipt

// MARK: Network Service

class NetworkService: Common.NetworkService {
    
    static let shared = NetworkService()
    
    @discardableResult
    func request1 (_ completion: @escaping Completion<[Account]>) -> Self {
        requestXML(completion)
        return self
    }
    
    @discardableResult
    func request2 (_ id: Int?, _ completion: @escaping Completion<Account>) -> Self {
        requestJSON(completion)
        return self
    }
    
    @discardableResult
    func request3 (_ completion: @escaping Completion<Receipt>) -> Self {
        requestSOAP(completion)
        return self
    }
    
    @discardableResult
    func request4 (_ completion: @escaping Completion<Receipt>) -> Self {
        requestSOAP(completion)
        return self
    }
}
