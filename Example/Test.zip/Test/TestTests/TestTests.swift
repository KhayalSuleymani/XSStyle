//
//  TestTests.swift
//  TestTests
//
//  Created by khayal suleymani on 16.09.25.
//

import XCTest
@testable import Test

final class ModuleTests: XCTestCase {
    
    func test () {
        
        let c = Test()
        c
            .move(by: .authorize(.view1(.mock)))
            .move(by: .dashboard(.tab1(.products(.mock))))
            .move(by: .dashboard(.tab2(.opertions(.mock))))
            .move(by: .dashboard(.tab3(.payments(.view1(.mock)))))
            .move(by: .dashboard(.tab4(.products(.mock))))
        
        let c1 = Tab1()
        c1
            .move(by: .accounts(.view1(.mock)))
            .move(by: .cards(.view1(.mock)))
            .move(by: .deposits(.view1(.mock)))
            .move(by: .loans(.view1(.mock)))
        
        let c2 = Tab2()
        c2
            .move(by: .payments(.view1(.mock)))
            .move(by: .transfers(.view1(.mock)))
        
        let c3 = Tab3()
        c3
            .move(by: .accounts(.view1(.mock)))
            .move(by: .cards(.view1(.mock)))
            .move(by: .deposits(.view1(.mock)))
            .move(by: .loans(.view1(.mock)))
        
        let c4 = Tab4()
        c4
            .move(by: .accounts(.view1(.mock)))
            .move(by: .cards(.view1(.mock)))
            .move(by: .deposits(.view1(.mock)))
            .move(by: .loans(.view1(.mock)))
    }
}
