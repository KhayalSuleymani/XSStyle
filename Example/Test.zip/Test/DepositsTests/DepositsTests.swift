//
//  DepositsTests.swift
//  DepositsTests
//
//  Created by khayal suleymani on 03.02.26.
//

import XCTest
@testable import Deposits

@MainActor
final class DepositsTests: XCTestCase {
    func test () {
        let sut = Deposits()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
    }
}
