//
//  Payments.h
//  Payments
//
//  Created by khayal suleymani on 22.01.26.
//

#import <Foundation/Foundation.h>

//! Project version number for Payments.
FOUNDATION_EXPORT double PaymentsVersionNumber;

//! Project version string for Payments.
FOUNDATION_EXPORT const unsigned char PaymentsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Payments/PublicHeader.h>


