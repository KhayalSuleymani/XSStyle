//
//  View1(vm).swift
//  Transactions
//
//  Created by khayal suleymani on 11.12.25.
//

import Common

// View
typealias View1 = View<Model1>

// View Model
class ViewModel1: ViewModel<Model1> {
    @discardableResult
    override func move(by c: Coordinator<Route>) -> Self {
        NetworkService.shared
            .request1(weakify(self) {
                $0.configure(.init($1))
            }).request3(weakify(self) {
                $0.configure(.init(.mock))
            }).request4(weakify(self) {
                $0.configure(.init(.mock))
            })
        return self
    }
}
