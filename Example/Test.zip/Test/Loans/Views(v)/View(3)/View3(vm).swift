//
//  View3(vm).swift
//  Transactions
//
//  Created by khayal suleymani on 11.12.25.
//

import Common

// View
typealias View3 = View<Model3>

// View Model
class ViewModel3: ViewModel<Model3> {
    @discardableResult
    override func move(by c: Coordinator<Route>) -> Self {
        NetworkService.shared
            .request3(weakify(self) {
                $0.configure(.init($1))
        })
        return self
    }
}
