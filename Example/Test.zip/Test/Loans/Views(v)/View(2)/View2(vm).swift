//
//  View2(vm).swift
//  Transactions
//
//  Created by khayal suleymani on 11.12.25.
//

import Common

// View
typealias View2 = View<Model2>

// View Model
class ViewModel2: ViewModel<Model2> {
    @discardableResult
    override func move(by c: Coordinator<Route>) -> Self {
        NetworkService.shared
            .request2(model.data?.id, weakify(self) {
                $0.configure(.init($1))
        })
        return self
    }
}

