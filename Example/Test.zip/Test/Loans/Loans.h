//
//  Loans.h
//  Loans
//
//  Created by khayal suleymani on 03.02.26.
//

#import <Foundation/Foundation.h>

//! Project version number for Loans.
FOUNDATION_EXPORT double LoansVersionNumber;

//! Project version string for Loans.
FOUNDATION_EXPORT const unsigned char LoansVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Loans/PublicHeader.h>


