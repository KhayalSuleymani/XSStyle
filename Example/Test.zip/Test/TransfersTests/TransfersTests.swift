//
//  TransfersTests.swift
//  TransfersTests
//
//  Created by khayal suleymani on 22.01.26.
//

import XCTest
@testable import Transfers

@MainActor
final class TransfersTests: XCTestCase {
    func test () {
        let sut = Transfers()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
    }
}
