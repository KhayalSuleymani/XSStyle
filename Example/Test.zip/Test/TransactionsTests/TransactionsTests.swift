//
//  TransactionsTests.swift
//  TransactionsTests
//
//  Created by khayal suleymani on 14.10.25.
//

import XCTest
@testable import Common
@testable import Transactions

@MainActor
final class TransactionsTests: XCTestCase {
    func test () {
        let sut = Transactions()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
    }
}
