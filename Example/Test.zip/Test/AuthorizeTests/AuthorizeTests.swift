//
//  AuthorizeTests.swift
//  AuthorizeTests
//
//  Created by khayal suleymani on 24.09.25.
//

import XCTest
@testable import Authorize

@MainActor
final class AuthorizeTests: XCTestCase {
    func test () {
        let sut = Authorize()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
            .move(by: .view4(.mock))
    }
}
