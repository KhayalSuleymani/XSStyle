//
//  IbansTests.swift
//  IbansTests
//
//  Created by khayal suleymani on 03.02.26.
//

import XCTest
@testable import Ibans

@MainActor
final class LoansTests: XCTestCase {
    func test () {
        let sut = Accounts()
        sut
            .move(by: .view1(.mock))
            .move(by: .view2(.mock))
            .move(by: .view3(.mock))
    }
}
