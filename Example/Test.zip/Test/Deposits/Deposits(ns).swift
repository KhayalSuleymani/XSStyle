//
//  Authorize(ns).swift
//  Authorize
//
//  Created by khayal suleymani on 14.10.25.
//

import Common

typealias Deposit = DepositsRoute.Deposit
typealias Receipt = DepositsRoute.Receipt

// MARK: Network Service

class NetworkService: Common.NetworkService {
    
    static let shared = NetworkService()
    
    @discardableResult
    func request1 (_ completion: @escaping Completion<[Deposit]>) -> Self {
        requestXML(completion)
        return self
    }
    
    @discardableResult
    func request2 (_ id: Int?, _ completion: @escaping Completion<Deposit>) -> Self {
        requestJSON(completion)
        return self
    }
    
    @discardableResult
    func request3 (_ completion: @escaping Completion<Receipt>) -> Self {
        requestSOAP(completion)
        return self
    }
    
    @discardableResult
    func request4 (_ completion: @escaping Completion<Receipt>) -> Self {
        requestSOAP(completion)
        return self
    }
}
